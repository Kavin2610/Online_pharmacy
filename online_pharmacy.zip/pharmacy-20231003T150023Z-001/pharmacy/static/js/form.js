console.log("javaScript from static folder is working!");
alert("hey it is working!")